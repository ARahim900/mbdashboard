"use client"
import WaterDashboard from "@/components/water-dashboard"

export default function Home() {
  return (
    <main>
      <WaterDashboard />
    </main>
  )
}
